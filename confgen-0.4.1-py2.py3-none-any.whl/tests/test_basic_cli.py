from confgen import cli

def test_foo(runner):
    assert 1 + 1 == 2
